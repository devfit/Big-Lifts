// box2d.js
// put initalizations here (if any)

b2 = native; // namespace extension for box2d
b2.SCALE = 0.1;  // for Impact games 

b2Body = {
    b2_staticBody: 0,
    b2_kinematicBody: 1,
    b2_dynamicBody: 2
}

// The following test code is put here temporarily
/*
apm = new native.AppMobi();
apm.log("Starting box2D.js");
gravity = new b2.Vec2(0, -10);
doSleep = true;*/
/*
var myListenerClass=function(){};
myListenerClass.prototype = new b2.ContactListener();
myListenerClass.prototype.BeginContact = function (a) {
	apm.log("****** in Listener!!!!!!!!!!");
	apm.log("a = "+a);
}
var myListener = new myListenerClass();*/
/*
myListener = new b2.ContactListener();
myListener.BeginContact = function (a) {
	apm.log("****** in Listener!!!!!!!!!!");
	while(typeof a != "undefined") {
		b1=a.GetFixtureA().GetBody();
		b2=a.GetFixtureB().GetBody();
		b1.GetPosition().Log();
		b2.GetPosition().Log();
		a = a.GetNext();
	}
}

world = new b2.World(gravity, doSleep);
world.SetContactListener(myListener);

groundBodyDef = new b2.BodyDef();
groundBodyDef.position.Set(0, -10);
groundBody=world.CreateBody(groundBodyDef);
groundBox= new b2.PolygonShape();
groundBox.SetAsBox(50, 10);
groundBody.CreateFixture2(groundBox);

bodyDef = new b2.BodyDef();
bodyDef.type = 2; //b2_dynamicBody;
bodyDef.position.Set(0, 4);
body = world.CreateBody(bodyDef);
dynamicBox = new b2.PolygonShape();
dynamicBox.SetAsBox(1, 1);
fixtureDef = new b2.FixtureDef();
fixtureDef.shape = dynamicBox;
fixtureDef.density = 1;
fixtureDef.friction = 0.3;
body.CreateFixture(fixtureDef);
//body.CreateFixture2(dynamicBox);

timeStep = 1/60;
velocityIterations = 6;
positionIterations = 2;

for(i = 0; i < 60; ++i)
{
    world.Step(timeStep, velocityIterations, positionIterations);
//    world.ClearForces();
    position = body.GetPosition();
//    float32 angle = body->GetAngle();
   // apm.log(position.y);
   // apm.log("i="+i);
}
*/
/*
v2 = new b2.Vec2(50, 100);

s1 = new b2.PolygonShape();
s1.m_centroid=v2;
s1.SetAsBox(10, 20);
v5=s1.m_vertices;
v6=v5[0];
v6.Log();
v6=v5[1];
v6.Log();
v6=v5[2];
v6.Log();
v6=v5[3];
v6.Log();
*/
/*
//var g = new b2.Vec2(0, 90*b2.SCALE); // does not work
g = new b2.Vec2(0, 9);
body = new b2.BodyDef();
t=new b2.Vec2(1, 2);
body.test=t;
body.test.Log();

var world = new b2.World(g, false);
world.Step(33, 10, 5);
*/

/*
var ab= new b2.AABB;
var ub= new b2.Vec2(5, 5);
var lb=ub.GetNegative();
ab.lowerBound = lb;
ab.Log();
lb2=ab.lowerBound;
lb2.Log();
ab.lowerBound.Set(2, 2);
ab.upperBound.Set(10, 10);
ab.Log();
lb2.Log();
var c=ab.GetCenter();
c.Log();
*/
/*
var v1 = new b2.Vec2 (2, 3);
var a=v1.LengthSquared();
var b=v1.Normalize();
var v2 = new b2.Vec2(a, b);
v1.Log();
v2.Log();


var v1 = new b2.Vec2 (2, 10);
var v2 = new b2.Vec2(5, 5);
v2.x=3;
v2.y=-1;
v2.Log();
var v3 = new b2.Vec2(5, 6);
v3.Add(v1);
v3.Log();
v2.Subtract(v1);
v2.Log();
*/

/*
var r, s1, s2, t1, t2, i, d1, d2, precision = 2;

//round
for(var j = 0;j<5;j++) {
d1 = new Date();
r = 123.567
for(i=0;i<10000;i++) {
precision = Math.pow(10, precision || 0);
Math.round(this * precision) / precision;
r+=1.1;
}
d2 = new Date();
s1 = d2-d1;
d1 = d2;

r = 123.567
for(i=0;i<10000;i++) {
AppMobi.native.round(r, precision);
r+=1.1;
}
d2 = new Date();
t1 = d2-d1;
d1 = d2;

r = 123.567
for(i=0;i<10000;i++) {
AppMobi.native.round(r, precision);
r+=1.1;
}
d2 = new Date();
t2 = d2-d1;
d1 = d2;

r = 123.567
for(i=0;i<10000;i++) {
precision = Math.pow(10, precision || 0);
Math.round(this * precision) / precision;
r+=1.1;
}
d2 = new Date();
s2 = d2-d1;
d1 = d2;

console.log("round Math1: " + s1 + " Math2: " + s2 + " native1: " + t1 + " native2: " + t2)
}

//floor
for(var j = 0;j<5;j++) {
d1 = new Date();
r = 123.567
for(i=0;i<10000;i++) {
Math.floor(r);
r+=1.1;
}
d2 = new Date();
s1 = d2-d1;
d1 = d2;

r = 123.567
for(i=0;i<10000;i++) {
AppMobi.native.floor(r);
r+=1.1;
}
d2 = new Date();
t1 = d2-d1;
d1 = d2;

r = 123.567
for(i=0;i<10000;i++) {
AppMobi.native.floor(r);
r+=1.1;
}
d2 = new Date();
t2 = d2-d1;
d1 = d2;

r = 123.567
for(i=0;i<10000;i++) {
Math.floor(r);
r+=1.1;
}
d2 = new Date();
s2 = d2-d1;
d1 = d2;

console.log("floor Math1: " + s1 + " Math2: " + s2 + " native1: " + t1 + " native2: " + t2)
}

//ceil
for(var j = 0;j<5;j++) {
d1 = new Date();
r = 123.567
for(i=0;i<10000;i++) {
Math.ceil(r);
r+=1.1;
}
d2 = new Date();
s1 = d2-d1;
d1 = d2;

r = 123.567
for(i=0;i<10000;i++) {
AppMobi.native.ceil(r);
r+=1.1;
}
d2 = new Date();
t1 = d2-d1;
d1 = d2;

r = 123.567
for(i=0;i<10000;i++) {
AppMobi.native.ceil(r);
r+=1.1;
}
d2 = new Date();
t2 = d2-d1;
d1 = d2;

r = 123.567
for(i=0;i<10000;i++) {
Math.ceil(r);
r+=1.1;
}
d2 = new Date();
s2 = d2-d1;
d1 = d2;

console.log("ceil Math1: " + s1 + " Math2: " + s2 + " native1: " + t1 + " native2: " + t2)
}
*/