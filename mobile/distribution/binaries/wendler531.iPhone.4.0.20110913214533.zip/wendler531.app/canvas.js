// Set up the global 'window' object
window = this; // Make 'window' the global scope

//allow binding
Function.prototype.bind = function(bind) {
	var self = this;
	return function(){
		var args = Array.prototype.slice.call(arguments);
		return self.apply(bind || null, args);
	};
};

AppMobi = {
	//event hook callbacks: AppMobi.wasShown, AppMobi.willBeHidden
	wasShown: function(){},
	willBeHidden: function(){},
	updateFPS: function(fps){},
	
	// AppMobi.native provides basic utility functions, such as timers
	// and device properties
	native: new native.AppMobi(),
	
	//setup webview - provides access to parent AppMobiWebView
	webview: {
		//webview.execute to execute javascript in webview
		execute: function(js){ AppMobi.native.executeJavascriptInWebView(js); }
	},
	
	//setup canvas
	canvas: {
		context: new native.ScreenCanvas(),
		getContext: function(){ return this.context; }
	},
    
    isnative: true
};

Canvas = AppMobi.canvas;

localStorage = new native.LocalStorage();

devicePixelRatio = AppMobi.native.devicePixelRatio;
if( AppMobi.native.landscapeMode ) {
	innerWidth = AppMobi.native.screenWidth;
	innerHeight = AppMobi.native.screenHeight;
}
else {
	innerWidth = AppMobi.native.screenWidth;
	innerHeight = AppMobi.native.screenHeight;
}

screen = {
	availWidth: innerWidth,
	availHeight: innerHeight
};

navigator = {
	userAgent: AppMobi.native.userAgent
};

// AppMobi.native.log only accepts one param; console.log accepts multiple params
// and joins them
console = {
	log: function() {
		var args = Array.prototype.join.call(arguments, ', ');
		AppMobi.native.log( args );
	}
};

setTimeout = function(cb, t){ return AppMobi.native.setTimeout(cb, t); };
setInterval = function(cb, t){ return AppMobi.native.setInterval(cb, t); };
clearTimeout = function(id){ return AppMobi.native.clearTimeout(id); };
clearInterval = function(id){ return AppMobi.native.clearInterval(id); };


// The native Audio class mimics the HTML5 Audio element; we
// can use it directly as a substitute 
Audio = native.Audio;

// Set up a fake HTMLElement and document object, so DirectCanvas is happy
HTMLElement = function( tagName ){ 
	this.tagName = tagName;
	this.children = [];
};

HTMLElement.prototype.appendChild = function( element ) {
	this.children.push( element );
	
	// If the child is a script element, begin loading it
	if( element.tagName == 'script' ) {
		var id = AppMobi.native.setTimeout( function(){
			AppMobi.native.include( element.src ); 
			if( element.onload ) {
				element.onload();
			}
		}, 1 );
	}
};

Image = function() {
    var _src = '';
    /*
    failed: false,
    loadCallback: null,
     */
    
    this.prototype = new HTMLElement('image');

    this.data = null;
    this.src = null;//instead of path
    this.height = 0;
    this.width = 0;
    this.loaded = false;
    this.onabort = null;
    this.onerror = null;
    this.onload = null;//instead of loadCallback
    this._onload = function( width, height ) {
		this.width = width;
		this.height = height;
		this.loaded = true;
	};
    this._onload2 = function() {
		if( this.onload ) {
			this.onload( this.src, true );
		}
	};
    this.__defineGetter__("src", function(){
        return _src;
    });
    
    this.__defineSetter__("src", function(val){
        _src = val;
        this.data = new native.Texture( this.src, this._onload.bind(this) );
        this._onload2();//call after assigning this.data, which needs to be available for the onload
    });
    
    return this;
}

document = {
	location: { href: 'index' },
	
	head: new HTMLElement( 'head' ),
	body: new HTMLElement( 'body' ),
	
	createElement: function( name ) {
		if( name == 'canvas' ) {
			return new native.Canvas();
		} else if ( name == 'image') {
			return new Image();
        } else {
            return new HTMLElement( 'script' );
        }
	},
	
	getElementById: function( id ){	
		return null;
	},
	
	getElementsByTagName: function( tagName ){
		if( tagName == 'head' ) {
			return [document.head];
		}
	},
	
	addEventListener: function( type, callback ){
		if( type == 'DOMContentLoaded' ) {
			setTimeout( callback, 1 );
		}
	}
};
addEventListener = function( type, callback ){};


