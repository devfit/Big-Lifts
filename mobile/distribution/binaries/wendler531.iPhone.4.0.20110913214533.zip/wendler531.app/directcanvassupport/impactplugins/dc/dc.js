ig.module(
	'plugins.dc.dc'
)
.requires(
	'plugins.dc.animation',
	'plugins.dc.loader',
    'plugins.dc.image',
    'plugins.dc.font',
	'plugins.dc.system'
)
.defines(function(){

/* empty module to require all dc plugin modules */

});

//other overrides
