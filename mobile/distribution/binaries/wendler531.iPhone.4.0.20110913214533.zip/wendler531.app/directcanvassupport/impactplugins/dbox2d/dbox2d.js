ig.module(
	'plugins.dbox2d.dbox2d'
)
.requires(
	'plugins.dbox2d.lib',
	'plugins.dbox2d.debug',
	'plugins.dbox2d.entity',
	'plugins.dbox2d.game'
)
.defines(function(){
/* empty module to require all db2d plugin modules */
});