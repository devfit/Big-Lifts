 if (typeof (AppMobiInit) != 'object')
        AppMobiInit = {};

    /**
    * This represents the PayMobi API itself, and provides a global namespace for accessing
    * information about the state of PayMobi.
    * @class
    */
    PayMobi = {
        queue: {
            ready: true,
            commands: [],
            timer: null
        },
        _constructors: [],
        jsVersion: '3.2.7'
    };

    /**
    * Boolean flag indicating if the PayMobi API is available and initialized.
    */
    PayMobi.available = false;

    /**
    * Add an initialization function to a queue that ensures it will run and initialize
    * application constructors only once PayMobi has been initialized.
    * @param {Function} func The function callback you want run once PayMobi is initialized
    */
    PayMobi.addConstructor = function(func) {
        var state = document.readyState;
        if ((state == 'loaded' || state == 'complete') && AppMobiInit.uuid != null)
            func();
        else
            PayMobi._constructors.push(func);
    };

    (function() {
        var timer = setInterval(function() {
            var state = document.readyState;
            if ((state == 'loaded' || state == 'complete') && AppMobiInit.uuid != null) {
                clearInterval(timer);
                //run constructors
                while (PayMobi._constructors.length > 0) {
                    var constructor = PayMobi._constructors.shift();
                    try {
                        constructor();
                    } catch (e) {
                        if (typeof (PayMobi.debug['log']) == 'function')
                            PayMobi.debug.log("Failed to run constructor: " + PayMobi.debug.processMessage(e));
                        else
                            alert("Failed to run constructor: " + e.message);
                    }
                }

                // all constructors run, now fire the deviceready event
                PayMobi.available = true;
                var e = document.createEvent('Events');
                e.initEvent('payMobi.device.ready', true, true);
                document.dispatchEvent(e);
            }
        }, 100);
    })();

    /**
    * Execute a PayMobi command in a queued fashion, to ensure commands do not
    * execute with any race conditions, and only run when PayMobi is ready to
    * recieve them.
    * @param {String} command Command to be run in PayMobi, e.g. "ClassName.method"
    * @param {String[]} [args] Zero or more arguments to pass to the method
    */
    PayMobi.exec = function() {
        PayMobi.queue.commands.push(arguments);
        if (PayMobi.queue.timer == null)
            PayMobi.queue.timer = setInterval(PayMobi.run_command, 10);
    };

    /**
    * Internal function used to dispatch the request to PayMobi.  This needs to be implemented per-platform to
    * ensure that methods are called on the phone in a way appropriate for that device.
    * @private
    */
    PayMobi.run_command = function() {

        if (!PayMobi.available || !PayMobi.queue.ready) {
            return;
        }

        PayMobi.queue.ready = false;

        var args = PayMobi.queue.commands.shift();
        if (PayMobi.queue.commands.length == 0) {
            clearInterval(PayMobi.queue.timer);
            PayMobi.queue.timer = null;
        }

        var uri = [];
        var dict = null;
        for (var i = 1; i < args.length; i++) {
            var arg = args[i];
            if (arg == undefined || arg == null)
                arg = '';
            if (typeof (arg) == 'object')
                dict = arg;
            else
                uri.push(encodeURIComponent(arg));
        }
        var url = "appmobi://" + args[0] + "/" + uri.join("/") + "/";
        if (dict != null) {
            var query_args = [];
            for (var name in dict) {
                if (typeof (name) != 'string')
                    continue;
                query_args.push(encodeURIComponent(name) + "=" + encodeURIComponent(dict[name]));
            }
            if (query_args.length > 0)
                url += "?" + query_args.join("&");
        }

        document.location = url;
    };

    /**
    * This class provides access to the appMobiPayments
    * @constructor
    */
    PayMobi.Payments = function() {
    };

    PayMobi.Payments.prototype.makePayment = function(dirty) {
        PayMobi.exec("PayMobiPayments.makePayment", dirty);
    };

    PayMobi.Payments.prototype.cancelPayment = function() {
        PayMobi.exec("PayMobiPayments.cancelPayment");
    };

	PayMobi.Payments.prototype.completePayment = function() {
		PayMobi.exec("PayMobiPayments.completePayment");
	};

    PayMobi.Payments.prototype.editPayment = function(id, data) {
        PayMobi.exec("PayMobiPayments.editPayment", id, data);
    };

    PayMobi.Payments.prototype.removePayment = function(id) {
        PayMobi.exec("PayMobiPayments.removePayment", id);
    };

    PayMobi.Payments.prototype.getPayments = function() {
        PayMobi.exec("PayMobiPayments.getPayments");
    };

    PayMobi.Payments.prototype.authorize = function(secret, user) {
        PayMobi.exec("PayMobiPayments.authorize", secret, user);
    };

	PayMobi.Payments.prototype.updatePaymentInfo = function(prefid, info, verify) {
		PayMobi.exec("PayMobiPayments.updatePaymentInfo", prefid, info, verify);
	};

    PayMobi.addConstructor(function() {
        if (typeof PayMobi.payments == "undefined") PayMobi.payments = new PayMobi.Payments();
    });

    /**
    * this represents the mobile device, and provides properties for inspecting the model, version, UUID of the
    * phone, etc.
    * @constructor
    */
    PayMobi.Device = function() {
        this.available = PayMobi.available;
        this.platform = null;
        this.osversion = null;
        this.model = null;
        this.uuid = null;
        this.appmobiversion = null;
        this.connection = null;
        this.hasInAppPay = null;
        try {
            this.platform = AppMobiInit.platform;
            this.osversion = AppMobiInit.version;
            this.model = AppMobiInit.model;
            this.uuid = AppMobiInit.uuid;
            this.appmobiversion = AppMobiInit.appmobiversion;
            this.connection = AppMobiInit.connection;
            this.hasInAppPay = AppMobiInit.hasInAppPay;
        } catch (e) {
            this.available = false;
        }
    }

    PayMobi.addConstructor(function() {
        if (typeof PayMobi.device == "undefined") PayMobi.device = new PayMobi.Device();
    });